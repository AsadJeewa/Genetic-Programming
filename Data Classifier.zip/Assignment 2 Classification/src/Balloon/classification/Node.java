package Balloon.classification;

import java.util.ArrayList;

public class Node{
	private String value;
	private int arity;
	private ArrayList<Node> children;
	private int hits = 0;
	private double rawFitness = 0.0;
	private int id = 0;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	// public Node(Node node){
	// this = node;
	// }

	public Node() {
		value = "";
		children = new ArrayList<Node>();
		arity = 0;
	}

	public Node(String value, int arity) {
		this.value = value;
		this.arity = arity;
		children = new ArrayList<Node>();
	}

public Node(Node n) {
	this.value = n.value;
	this.arity = n.arity;
this.children = n.children;
this.hits = n.hits;
this.rawFitness = n.rawFitness;
this.id = n.id;
}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getArity() {
		return arity;
	}

	public void setArity(int arity) {
		this.arity = arity;
	}

	public int getHits() {
		return hits;
	}

	public void setHits(int hits) {
		this.hits = hits;
	}

	public double getRawFitness() {
		return rawFitness;
	}

	public void setRawFitness(double rawFitness) {
		this.rawFitness = rawFitness;
	}

	public ArrayList<Node> getChildren() {
		return children;
	}

	public void setChildren(ArrayList<Node> children) {
		this.children = children;
	}

	public boolean hasChildren() {
		return children.size() != 0;
	}
	
//	@Override
//	protected Object clone() throws CloneNotSupportedException {
//		return new Node(value, arity, children, hits, rawFitness, id);
//	}
}
