package Balloon.classification;

//import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
//import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Evaluate {

	static double input;
	private int numFitnessCases = 0;
	static double target;
	static int hits;
	static double rawFitness = 0;
	
	private double bound = 0.001;
	private String filename = "";

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public double getBound() {
		return bound;
	}

	public void setBound(double bound) {
		this.bound = bound;
	}

	/** function to evaluate tree */
//	public double calculate(Node n) {//evaluate expression tree
//		if (n.getChildren().size() == 0)// leaf
//			if(n.getValue()=="x")
//			return input;
//			else return Integer.parseInt(n.getValue());
//			//else return 1;
//			else {
//			double result = 0.0;
//			double left = calculate(n.getChildren().get(0));
//			double right = calculate(n.getChildren().get(1));
//			String operator = n.getValue();
//
//			switch (operator) {
//			case "+":
//				result = left + right;
//				break;
//			case "-":
//				result = left - right;
//				break;
//			case "*":
//				result = left * right;
//				break;
//			case "/":
//				if (right == 0.0)
//					result = 1;
//				else
//					result = left / right;
//				break;
//			default:
//				result = left + right;
//				break;
//			}
//			return result;
//		}
//	}
	
	public int getNumFit() throws FileNotFoundException {
	    // finds resource relative to the class location
	    InputStream url = this.getClass().getResourceAsStream("/Balloon/res/"+filename);//src is root of classpath

	    numFitnessCases = 0;
	    Scanner sc = new Scanner(url);
	    sc.nextLine();
		while (sc.hasNextLine()) {
sc.nextLine();
		numFitnessCases++;
		}
		sc.close();
				return numFitnessCases;
		}
	
	public void evaluate(Population population) throws FileNotFoundException {
		long start = System.currentTimeMillis();
		    // finds resource relative to the class location
		    InputStream url = this.getClass().getResourceAsStream("/Balloon/res/"+filename);//src is root of classpath

		//File file = new File("res/FitnessCases1.txt");
		    
		// Main.genPop();
		ArrayList<Node> pop = population.getPopulation();
Scanner sc = new Scanner(url);
		Node cur;
		for (Node n : pop) {
			String[] str = null;
			sc.nextLine();
			while (sc.hasNext()) {
cur = n;
				String line = sc.nextLine();
				str = line.split(",");
				
				while(!SetDef.getTermSet().contains(cur.getValue())){
				int index = SetDef.getAttribute(cur.getValue());
					//pick correct child
					cur = cur.getChildren().get(SetDef.getChild(str[index]));
//				System.out.println(cur.getValue());	
				}
//				int curClassi = Integer.parseInt(cur.getValue());
//				int classi = Integer.parseInt(str[str.length-1]);			
//				if(curClassi==classi)
				if(cur.getValue().equalsIgnoreCase(str[str.length-1]))
					hits++;
//				for(String e:str)
//					if(!e.equals("F")&&!e.equals("T"))
//					System.out.print(FunctionDef.getChild(e)+" "+e+" | ");
//			int classi = Integer.parseInt(str[str.length-1]); 
//				System.out.println(classi);
			}
			n.setRawFitness(hits);
			n.setHits(hits);
//			System.out.println("hits: "+hits);
//			System.out.println("========================================");
			hits = 0;
			url = this.getClass().getResourceAsStream("/Balloon/res/"+filename);
			sc = new Scanner(url);
		}
		sc.close();
		long end = System.currentTimeMillis();
		//System.out.println(((end-start)/1000.0)+"s");
	}
	
	public void evaluate(Node n) throws FileNotFoundException {
	    InputStream url = this.getClass().getResourceAsStream("/Balloon/res/"+filename);//src is root of classpath
Scanner sc = new Scanner(url);
	Node cur;
		String[] str = null;
		sc.nextLine();
		while (sc.hasNext()) {
cur = n;
			String line = sc.nextLine();
			str = line.split(",");
			
			while(!SetDef.getTermSet().contains(cur.getValue())){
			int index = SetDef.getAttribute(cur.getValue());
				//pick correct child
				cur = cur.getChildren().get(SetDef.getChild(str[index]));
//			System.out.println(cur.getValue());	
			}
//			if(curClassi==classi)
				if(cur.getValue().equalsIgnoreCase(str[str.length-1]))
					hits++;
		}
		n.setRawFitness(hits);
		n.setHits(hits);
//		System.out.println("hits: "+hits);
//		System.out.println("========================================");
		hits = 0;
		sc.close();
	}

}

