package Balloon.classification;
import java.util.ArrayList;

public class SetDef {

	private static ArrayList<String> funcSet = new ArrayList<String>();
	private static ArrayList<Integer> aritySet = new ArrayList<Integer>();
	private static ArrayList<String> termSet = new ArrayList<String>();
	
	public static void init() {// initialise primitives
		termSet.add("T");
			termSet.add("F");
		funcSet.add("Color");
		aritySet.add(2);
		funcSet.add("Size");
		aritySet.add(2);
		funcSet.add("Act");
		aritySet.add(2);
		funcSet.add("Age");
		aritySet.add(2);
		funcSet.add("Inflated");
		aritySet.add(2);
	}
	
	
	public static int getAttribute(String node){
		if(node=="Color")
			return 0;
		else if(node=="Size")
			return 1;
			else if(node=="Act")
				return 2;
				else if(node=="Age")
					return 3;
				else if(node=="Inflated")
					return 3;
					else
					return -1;
	}
	public static int getChild(String edge){
		if(edge.equalsIgnoreCase("yellow"))
			return 0;
		if(edge.equalsIgnoreCase("purple"))
			return 1;
	
		if(edge.equalsIgnoreCase("large"))
			return 0;
		if(edge.equalsIgnoreCase("small"))
			return 1;
		
		if(edge.equalsIgnoreCase("stretch"))
			return 0;
		if(edge.equalsIgnoreCase("dip"))
			return 1;
		
		if(edge.equalsIgnoreCase("adult"))
			return 0;
		if(edge.equalsIgnoreCase("child"))
			return 1;
		
		return -1;//error
	}
	public static ArrayList<String> getFuncSet() {
		return funcSet;
	}
	public void setFuncSet(ArrayList<String> funcSet) {
		SetDef.funcSet = funcSet;
	}
	public static ArrayList<Integer> getAritySet() {
		return aritySet;
	}
	public void setAritySet(ArrayList<Integer> aritySet) {
		SetDef.aritySet = aritySet;
	}
	public static ArrayList<String> getTermSet() {
		return termSet;
	}
	public void setTermSet(ArrayList<String> termSet) {
		SetDef.termSet = termSet;
	}
}
