package Balloon.classification;
import java.util.ArrayList;

public class Population implements Cloneable {

	private int popSize = 10;
	private int maxDepth = 6;
	private ArrayList<Node> population;// store root of each member
private boolean trivial = false;
private boolean constant = false;
private boolean ephConstant = false;

	public boolean isEphConstant() {
	return ephConstant;
}

public void setEphConstant(boolean ephConstant) {
	this.ephConstant = ephConstant;
}

	public boolean isConstant() {
	return constant;
}

public void setConstant(boolean constant) {
	this.constant = constant;
}

	public Population(int popSize, int maxDepth) {
		this.popSize = popSize;
		this.maxDepth = maxDepth;
		population = new ArrayList<Node>();
	}
	
	public Population(int popSize, int maxDepth, ArrayList<Node> population, boolean trivial) {
		this.popSize = popSize;
		this.maxDepth = maxDepth;
		this.population = population;
		this.trivial = trivial;
	}

	public Population() {
		population = new ArrayList<Node>();
	}

	public int getPopSize() {
		return popSize;
	}

	public void setPopSize(int popSize) {
		this.popSize = popSize;
	}

	public int getMaxDepth() {
		return maxDepth;
	}

	public void setMaxDepth(int maxDepth) {
		this.maxDepth = maxDepth;
	}

	public ArrayList<Node> getPopulation() {
		return population;
	}

	public void setPopulation(ArrayList<Node> population) {
		this.population = population;
	}

	public boolean isTrivial() {
	return trivial;
}

public void setTrivial(boolean trivial) {
	this.trivial = trivial;
}

	public static final int GROW = 0, FULL = 1, RAMPED = 2;

	//static int arity = 2;
	static int count = 0;	

	static int curDepth = 0;
	static String str = "";
	static Node curNode, root;
	static String output = "";

//	public void init() {// initialise primitives
//		termSet.add("T");
//			termSet.add("F");
//	//		termSet.add("3");
//	//	if(ephConstant)
//	// termSet.add('U');
//		
//		funcSet.add("A");
//		aritySet.add(1);
//		funcSet.add("B");
//		aritySet.add(2);
//		funcSet.add("C");
//		aritySet.add(3);
//		funcSet.add("D");
//		aritySet.add(4);
//	}
	
	public void genPop(int method) {
SetDef.init();
		count = 0;
		if (method == GROW || method == FULL) {
			for (int i = 0; i < popSize; i++) {
				genMemberHelper(method, maxDepth);
			}
		}

		else {// RAMPED
//			int depth = 2;
			int num = 0;
			double dblDepth = (double) popSize / (double) (maxDepth - 1);

			boolean whole = dblDepth == Math.ceil(dblDepth);// test no fractions

			int randDepth = Main1.ran.nextInt(maxDepth - 1) + 2;
			int numDepth = (int) dblDepth;// floor

			int remainder = popSize - (numDepth * (maxDepth - 1));
			boolean odd = numDepth % 2 != 0;

			for (int i = 2; i <= maxDepth; i++) {// each depth
//				System.out.println("Depth " + depth++);
				for (int j = 0; j < numDepth; j++) {// each member
									if (odd) {
						if (j < (numDepth - 1) / 2)
							genMemberHelper(GROW, i);// grow at current depth
						else if (j < numDepth - 1)
							genMemberHelper(FULL, i);// full at current depth
					} else {
						if (j < numDepth / 2)
							genMemberHelper(GROW, i);// grow at current depth
						else
							genMemberHelper(FULL, i);// full at current depth
					}
				}
		
		
			if (odd) {// remaining 1 choose random fill or grow
			 num = Main1.ran.nextInt(2);
			 if (num == 0)
			 genMemberHelper(GROW, randDepth);// grow at current depth
			 else if (num == 1)
			 genMemberHelper(FULL, randDepth);// full at current depth
			 }
			} // for i
			
			 if (!whole) {
			 for (int j = 0; j < remainder; j++) {
			 num = Main1.ran.nextInt(2);
			 randDepth = Main1.ran.nextInt(maxDepth - 1) + 2;
			 if (num == 0)
			 genMemberHelper(GROW, randDepth);// grow at current depth
			 else if (num == 1)
			 genMemberHelper(FULL, randDepth);
			 }
			 }
		}
	}
	
	
	public void genMemberHelper(int method, int maxDepth) {
		if (!trivial) {// NO TRIVIAL TREES
			genMember(method, maxDepth);
		} else {// allow trivial
			count++;
			int triv = Main1.ran.nextInt(2);
			if (triv == 0) {// ALLOW TRIVIAL TREES
				String strRoot = SetDef.getTermSet().get(Main1.ran.nextInt(SetDef.getTermSet().size()));// random
				root = new Node(strRoot, arity(strRoot));
				//root = new Node(strRoot, aritySet.get(funcSet.indexOf(strRoot)));
				root.setId(count);
				population.add(root);
			} else if (triv == 1) {// NO TRIVIAL TREES
				genMember(method, maxDepth);
			}
		}
	}
	
	public void genMember(int method, int maxDepth) {
		count++;
		curDepth = 0;
		String strRoot = SetDef.getFuncSet().get(Main1.ran.nextInt(SetDef.getFuncSet().size()));// random
																// operator
			curDepth++;
//		root = new Node(strRoot, arity(strRoot));
		root = new Node(strRoot, SetDef.getAritySet().get(SetDef.getFuncSet().indexOf(strRoot)));
		root.setId(count);
		population.add(root);
		curDepth++;
		curNode = root;
		if (method == GROW)
			createChildrenGrow(curNode, maxDepth);
		else if (method == FULL)
			createChildrenFull(curNode, maxDepth);
	}

	public void createChildrenFull(Node node, int maxDepth) {// expand
																// using
																// full
																// method
		Node child;
		if (curDepth <= maxDepth) {
			for (int i = 0; i < node.getArity(); i++) {
//				System.out.println(node.getArity()+"!!!");
				if (curDepth != maxDepth) {
					str = SetDef.getFuncSet().get(Main1.ran.nextInt(SetDef.getFuncSet().size()));
					//child = new Node(str, arity(str));
					child = new Node(str, SetDef.getAritySet().get(SetDef.getFuncSet().indexOf(str)));
					node.getChildren().add(child);
				}
				else {
					str = SetDef.getTermSet().get(Main1.ran.nextInt(SetDef.getTermSet().size()));
					int con = 0;
					if(str == "U"){
					con = 	Main1.ran.nextInt(3);
					str =  ""+Character.forDigit(con, 10);
					//System.out.println(ch+"!!!!!");
					}
					child = new Node(str, arity(str));
					//child = new Node(str, aritySet.get(funcSet.indexOf(str)));
					node.getChildren().add(child);
				}
				curDepth++;
				createChildrenFull(child, maxDepth);
			}
			curDepth--;
		} else
			curDepth--;// backtrack
		return;
	}

	public void createChildrenGrow(Node node, int maxDepth) {
		Node child = null;

		if (curDepth <= maxDepth) {
			for (int i = 0; i < node.getArity(); i++) {
				if (curDepth == maxDepth) {// last level must be terminal
					str = SetDef.getTermSet().get(Main1.ran.nextInt(SetDef.getTermSet().size()));
					int con = 0;
					if(str == "U"){
						con = 	Main1.ran.nextInt(3);
						str =  ""+Character.forDigit(con, 10);
						//System.out.println(ch+"!!!!!");
						}
						child = new Node(str, arity(str));
						//child = new Node(str, aritySet.get(funcSet.indexOf(str)));
						node.getChildren().add(child);
				} else {
					int choice = Main1.ran.nextInt(2);// randomly choose terminal or
												// function
					switch (choice) {
					case 0:
						str = SetDef.getFuncSet().get(Main1.ran.nextInt(SetDef.getFuncSet().size()));
						//child = new Node(str, arity(str));
						child = new Node(str, SetDef.getAritySet().get(SetDef.getFuncSet().indexOf(str)));
						node.getChildren().add(child);
						curDepth++;
						createChildrenGrow(child, maxDepth);// only expand
															// function set
															// element
						break;
					case 1://TERMINAL
						str = SetDef.getTermSet().get(Main1.ran.nextInt(SetDef.getTermSet().size()));
						int con = 0;
						if(str == "U"){
							con = 	Main1.ran.nextInt(3);
							str =  ""+Character.forDigit(con, 10);
							//System.out.println(ch+"!!!!!");
							}
							child = new Node(str, arity(str));
//							child = new Node(str, aritySet.get(funcSet.indexOf(str)));
							node.getChildren().add(child);
						break;
					}
				}
			}
			curDepth--;
		} else
			curDepth--;
		return;
	}
	
	public Node getFittest(){//Max or Min
		double max= Double.MIN_VALUE;
		Node best = new Node();
		for(Node member:population){
			double cur = member.getRawFitness();
			if(cur>max){
				max = cur;
			best = member;
			}
		}
		return best;
	}

		public static void clone(Node node) {//evaluate expression tree
			if(node==null)
				return;
			else if (node.getChildren().size() == 0)// leaf
				return;// x sub 1
			else {
				ArrayList<Node> children = new ArrayList<Node>();
				for(Node child:node.getChildren()){
					Node ch =new Node(child);
				children.add(ch);
				}
				//node.getChildren().set(0, new Node(right));
				//node.getChildren().set(1, new Node(left));
				node.setChildren(children);
				for(Node child:node.getChildren()){
				clone(child);
				}
			}
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		ArrayList<Node> tempNodes = new ArrayList<Node>();
		for( Node n:population){
			Node tmp = new Node(n);
			clone(tmp);
			tempNodes.add(tmp);
			}
		return new Population(popSize, maxDepth, tempNodes, trivial);
	}
	
	public int arity(String val){
		for(int i =0;i<SetDef.getFuncSet().size();i++){
			if(SetDef.getFuncSet().get(i).equals(val))
				if(i==0)//first defined attribute
					return 1;
				else if (i==1)
					return 2;
					else if (i==2)
						return 3;
						else if (i==3)
							return 4;
						else
							return -1;
		}
		return 0;//terminal
		
	}
}
