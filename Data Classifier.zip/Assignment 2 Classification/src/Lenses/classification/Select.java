package Lenses.classification;
import java.util.ArrayList;

public class Select {
	private int tournSize = 4;
		private ArrayList<Node> tournament = new ArrayList<Node>();// store root of
																// each member
	private Node selected;

	public Node getSelected() {
		return selected;
	}

	public void setSelected(Node selected) {
		this.selected = selected;
	}

	public ArrayList<Node> getTournament() {
		return tournament;
	}

	public void setTournament(ArrayList<Node> tournament) {
		this.tournament = tournament;
	}

	public int getTournSize() {
		return tournSize;
	}

	public void setTournSize(int tournSize) {
		this.tournSize = tournSize;
	}
	
	public void select() {
		// Main.genPop();
		// Main.evaluate();
		tournament = new ArrayList<Node>();
		//ArrayList<Node> pop = (ArrayList<Node>) Main.population.getPopulation().clone();
		int index = Main2.ran.nextInt(Main2.population.getPopulation().size());
		if (tournSize > Main2.population.getPopulation().size())
			tournSize = Main2.population.getPopulation().size();
		for (int i = 0; i < tournSize; i++) {//create tournament
			tournament.add(Main2.population.getPopulation().get(index));
			index = Main2.ran.nextInt(Main2.population.getPopulation().size());
		}
		double min = Integer.MAX_VALUE;
		for (Node n : tournament) {//get fittest
			if (n.getRawFitness() < min) {
				selected = n;
				min = n.getRawFitness();
			}
		}
	}
}
