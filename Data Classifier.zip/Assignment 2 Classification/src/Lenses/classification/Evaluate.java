package Lenses.classification;

import java.io.FileNotFoundException;
import java.io.InputStream;
//import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Evaluate {

	static double input;
	private int numFitnessCases = 0;
	static double target;
	static int hits;
	static double rawFitness = 0;

	private ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
	private double bound = 0.001;
	private String filename = "";

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public double getBound() {
		return bound;
	}

	public void setBound(double bound) {
		this.bound = bound;
	}

	public int getNumFit() throws FileNotFoundException {
		// finds resource relative to the class location
		InputStream url = this.getClass().getResourceAsStream("/Lenses/res/" + filename);// src
																							// is
																							// root
																							// of
																							// classpath

		numFitnessCases = 0;
		Scanner sc = new Scanner(url);
		sc.nextLine();
		while (sc.hasNextLine()) {
			sc.nextLine();
			numFitnessCases++;
		}
		sc.close();
		return numFitnessCases;
	}

	public void evaluate(Population population) {
	//	long start = System.currentTimeMillis();
		// finds resource relative to the class location
		ArrayList<Node> pop = population.getPopulation();
		Node cur;
		for (Node n : pop) {
			boolean terminal = false;
			for(ArrayList<Integer> arr:data){//each fitness case
				cur = n;
				terminal = false;
				// terminal
				while (!terminal) {
					for (int ele : SetDef.getTermSet()) {
						String str = "" + ele;
						if (str.equals(cur.getValue())) {
							terminal = true;
							break;
						}
					}
					if (terminal)
						break;

					// not terminal
					int index = SetDef.getAttribute(cur.getValue());// current
																	// function
					// pick correct child
					cur = cur.getChildren().get(SetDef.getChild(arr.get(index)));
				}
				if (cur.getValue().equalsIgnoreCase("" + arr.get(arr.size() - 1)))
					hits++;
			}
			n.setRawFitness(hits);
			n.setHits(hits);
			hits = 0;
			terminal = false;
		}
	//	long end = System.currentTimeMillis();
	//	System.out.println(((end - start) / 1000.0) + "s EVAL");
	}

	public void evaluate(Node n){
		// long start = System.currentTimeMillis();
		boolean terminal = false;
		for(ArrayList<Integer> arr:data) {
			while (!terminal) {
				for (int ele : SetDef.getTermSet()) {//all terminals
					String str = "" + ele;
					if (str.equals(n.getValue())) {
						terminal = true;
						break;
					}
				}
				if (terminal)
					break;
				int index = SetDef.getAttribute(n.getValue());// current
																// function
				// pick correct child
				n = n.getChildren().get(SetDef.getChild(arr.get(index)));
			}

			if (n.getValue().equalsIgnoreCase("" + arr.get(arr.size() - 1)))
				hits++;
		}
		n.setRawFitness(hits);
		n.setHits(hits);
		hits = 0;
	}
	
	public void init(){
		InputStream url = this.getClass().getResourceAsStream("/Lenses/res/" + filename);
		Scanner sc = new Scanner(url);
		Scanner scLine;

		sc.nextLine();
		while (sc.hasNext()) {
			ArrayList<Integer> arr1 = new ArrayList<Integer>();
			String line = sc.nextLine();
		scLine = new Scanner(line);
			scLine.nextInt();// skip label
			while (scLine.hasNextInt()) {
				arr1.add(scLine.nextInt());
			}
			data.add(arr1);
		}
		sc.close();
	}

}
