package Lenses.classification;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.*;

public class Main2 {

	static Population population = new Population();
	static Population newPopulation = new Population();
	static Population tempPopulation = new Population();
	
	static Evaluate evaluation = new Evaluate();
	static Select selection = new Select();
	static GenOperators genOp = new GenOperators();

	//I/O
	static Scanner key = new Scanner(System.in);
	static Scanner scFile;
	static InputStream url;
	static String output = "";

	//constants
	public static final int GEN = 0, EVAL = 1, SELECT = 2, RAW = 3;
	public static final int REPRODUCTION = 0, CROSSOVER = 1, MUTATION = 2;
	
	//helper var
	static boolean success = false;
	static boolean firstEval = true;
	static boolean firstSel = true;
	static boolean firstGenOp = true;
	static boolean fin = false;
	static boolean elitism = true;
	static boolean el = true;
	static long start = 0,end = 0;

	//param
	static long seed = System.nanoTime();
	static Random ran = new Random(seed);
	static int numGen;


	@SuppressWarnings("resource")
	public static void genPop() {
		// seed = 3924827207865L;
		// ran = new Random(seed);

//		System.out.println("Random Seed: " + seed);
		// INPUT CONTROL PARAMETERS
		url = population.getClass().getResourceAsStream("/Lenses/res/Param.txt");
		scFile = new Scanner(url);

		String line = scFile.nextLine();
		Scanner str = new Scanner(line);
		evaluation.setFilename(str.next());
		System.out.println("Using file " + evaluation.getFilename() + "\n");
		
		line = scFile.nextLine();
		str = new Scanner(line);
		seed = str.nextLong();
		ran = new Random(seed);
		System.out.println("Random Seed: " + seed);
		
		line = scFile.nextLine();
		str = new Scanner(line);
		elitism = str.nextBoolean();
		System.out.println("ELITISM: "+elitism);
		if (elitism==true) {
			population.setEphConstant(true);
		}
		
		line = scFile.nextLine();
		str = new Scanner(line);
		population.setPopSize(str.nextInt());
		System.out.println("Population Size: " + population.getPopSize());

		line = scFile.nextLine();
		str = new Scanner(line);
		population.setMaxDepth(str.nextInt());
		System.out.println("Max Depth: " + population.getMaxDepth());

		line = scFile.nextLine();
		str = new Scanner(line);
		String method = str.next();
		if (method.equalsIgnoreCase("Full")) {
			System.out.println("\nPOPULATION USING FULL METHOD");
			population.genPop(Population.FULL);
		}
		if (method.equalsIgnoreCase("Grow")) {
			System.out.println("\nPOPULATION USING GROW METHOD");
			population.genPop(Population.GROW);
		}
		if (method.equalsIgnoreCase("Ramped")) {
			System.out.println("\nPOPULATION USING RAMPED HALF-AND-HALF METHOD");
			population.genPop(Population.RAMPED);
		}

		line = scFile.nextLine();
		str = new Scanner(line);
		numGen = str.nextInt();
		System.out.println("Number Generations: " + numGen);

		// get applications Rates
		line = scFile.nextLine();
		str = new Scanner(line);
		genOp.setCrossRate(str.nextDouble());
		System.out.println("Crossover Rate: " + (genOp.getCrossRate() * 100) + "%");

		line = scFile.nextLine();
		str = new Scanner(line);
		genOp.setRepRate(str.nextDouble());
		System.out.println("Reproduction Rate: " + (genOp.getRepRate() * 100) + "%");

		line = scFile.nextLine();
		str = new Scanner(line);
		genOp.setMutRate(str.nextDouble());
		System.out.println("Mutation Rate: " + (genOp.getMutRate() * 100) + "%\n");

		str.close();
	}

	public static String getOutput(Node node) {// output prefix notation
	boolean children = false;
		if (node == null)
			return output;
		else{
			Queue queue = new LinkedList();
			queue.add(node);
			output += node.getValue() + " ";
			output += "| ";
			//rootNode.visited = true;
			while(!queue.isEmpty()) {
				Node cur = (Node)queue.remove();
				for(Node child:cur.getChildren()){
					output += child.getValue() + " ";
					queue.add(child);
				children = true;
				}
				if(children)
				output += "| ";
				children=false;
			}
			return output;
		}
		//		else {
//			output += node.getValue() + " ";
//			if (node.hasChildren()) {
//				for(Node n:node.getChildren()){
//				if (n != null)
//					getOutput(n);
//			}
//			}
//			return output;
//		}
	}

//	public static String getOutput(Node node) {// output prefix notation
//		if (node == null)
//			return output;
//				else {
//			output += node.getValue() + " ";
//			if (node.hasChildren()) {
//				for(Node n:node.getChildren()){
//				if (n != null)
//					getOutput(n);
//			}
//			}
//			return output;
//		}
//	}
	public static ArrayList<String> outputPop(int mode, Population population) {// output
																				// entire
		// population
		ArrayList<String> outArr = new ArrayList<String>();
		String output = "";
		ArrayList<Node> pop = population.getPopulation();
		for (int i = 0; i < pop.size(); i++) {
			Node n = pop.get(i);
			String member = "Member " + n.getId() + ": ";
			Main2.output = "";
			String value = getOutput(n);// +"\nHits:"+
										// n.getHits()+"\nFitness:
										// "+n.getRawFitness();

			Main2.output = "";
			output = String.format("%1$-15s %2$-30s", member, value);
			// output = value;
			if (mode == EVAL) {// include hits ratio and fitness
				String fitness = "Hits:" + Math.round(n.getHits() * 100000.0) / 100000.0 + ", Raw Fitness: "
						+ Math.round(n.getRawFitness() * 100000.0) / 100000.0;
				// output = String.format("%1$-15s %2$-30s %3$-30s", member,
				// value, fitness);
				output = String.format("%1$-30s %2$-30s", value, fitness);
			}
			outArr.add(output);
		}
		Main2.output = "";
		return outArr;
	}

	public static ArrayList<String> outputTourn() {// output entire tournament
		ArrayList<String> outArr = new ArrayList<String>();
		String output = "";
		ArrayList<Node> tourn = selection.getTournament();
		for (int i = 0; i < tourn.size(); i++) {
			Main2.output = "";
			Node n = tourn.get(i);
			String member = "Member " + n.getId() + ": ";
			String value = Main2.getOutput(n);
			String fitness = "Hits:" + Math.round(n.getHits() * 100000.0) / 100000.0 + ", Raw Fitness: "
					+ Math.round(n.getRawFitness() * 100000.0) / 100000.0;
			output = String.format("%1$-15s %2$-30s %3$-30s", member, value, fitness);
			outArr.add(output);
		}
		Main2.output = "";
		return outArr;
	}

	public static String outputMember(Node n, int mode) {// output a single
															// individual
		String output = "";
		Main2.output = "";
		String member = "Member " + n.getId() + ": ";
		String value = Main2.getOutput(n);
		if (mode == EVAL) {
			String fitness = "Hits:" + Math.round(n.getHits() * 100000.0) / 100000.0 + ", Raw Fitness: "
					+ Math.round(n.getRawFitness() * 100000.0) / 100000.0;
			Main2.output = "";
			// output = String.format("%1$-15s %2$-30s %3$-30s", member, value,
			// fitness);
			output = String.format("%1$-30s %2$-30s", value, fitness);
		} else if (mode == GEN)
			// output = String.format("%1$-15s %2$-30s", member, value);
			output = value;
		else
			output = value;
		return output;
	}

	public static void evaluate(Population pop) throws FileNotFoundException {
		if (firstEval) {
			String line = scFile.nextLine();
			Scanner str = new Scanner(line);
			evaluation.setBound(str.nextDouble());
			System.out.println("Bound: " + evaluation.getBound());

			str.close();
			firstEval = false;
		evaluation.init();
		}
		evaluation.evaluate(pop);
	}

	public static void select() throws FileNotFoundException, CloneNotSupportedException {// create
																							// a
		// tournament
		// and select
		// fittest
		// individual
		if (firstSel) {
			String line = scFile.nextLine();
			Scanner str = new Scanner(line);
			selection.setTournSize(str.nextInt());
			System.out.println("Tournament Size: " + selection.getTournSize());
			str.close();
			firstSel = false;
		}
		selection.select();
	}

	public static void genOp(int inOp) throws FileNotFoundException, CloneNotSupportedException {
		select();// SELECT FIRST INDIVIDUAL

		tempPopulation = (Population) population.clone();

		if (firstGenOp) {
			String line = scFile.nextLine();
			Scanner str = new Scanner(line);
			genOp.setMaxOffspringSize(str.nextInt());
			System.out.println("Max Offspring Size: " + genOp.getMaxOffspringSize());

			str.close();
			firstGenOp = false;
		}
		// selection.select();
		Node offspring1 = new Node();
		Node offspring2 = new Node();
		switch (inOp) {
		case REPRODUCTION:
			Node root;
			if(elitism){
			if(el){//copy fittest individual
			root = population.getFittest();	
			//System.out.println("!!!!!!!!!"+outputMember(population.getFittest(),EVAL)+"!!!!!!!!!!!!!!!");
			el = false;
			}
			else
			root = selection.getSelected();
			}
			else
				root = selection.getSelected();
			// System.out.println("REPRODUCTION");
			// System.out.println("SELECTED PARENT");
			// System.out.println(outputMember(root, EVAL));

			offspring1 = genOp.reproduce(root);

			newPopulation.getPopulation().add(offspring1);

			evaluation.evaluate(offspring1);
			if (offspring1.getHits() == evaluation.getNumFit()) {
				System.out.println("SOLUTION FOUND");
				fin = true;
			}

			// evaluate();//reevaluate with new member

			// System.out.println("\nOFFSPRING");
			// System.out.println(outputMember(offspring1, EVAL));
			// System.out.println("=====================================");
			break;
		case CROSSOVER:
			// System.out.println("=====================================");
			// System.out.println("CROSSOVER");
			// System.out.println("SELECTED PARENTS");

			Node inRoot1 = selection.getSelected();
			int index = population.getPopulation().indexOf(inRoot1);
			Node root1 = tempPopulation.getPopulation().get(index);

			// System.out.println(outputMember(root1, EVAL));
			Node inRoot2;
			// do{
			select();// second member
			inRoot2 = selection.getSelected();
			// }while(root2.getId()==root1.getId());

			index = population.getPopulation().indexOf(inRoot2);
			Node root2 = tempPopulation.getPopulation().get(index);
			// System.out.println(outputMember(root2, EVAL));

			Node[] offspring = genOp.crossover(root1, root2);
			// Node [] offspring = genOp.crossover(root1, root1);

			// System.out.println("Crossover Point 1: "+genOp.getPoint1());
			// System.out.println("Crossover Point 2: "+genOp.getPoint2());

			// evaluate();

			offspring1 = offspring[0];
			offspring2 = offspring[1];

			newPopulation.getPopulation().add(offspring1);
			newPopulation.getPopulation().add(offspring2);

			evaluation.evaluate(offspring1);
			if (offspring1.getHits() == evaluation.getNumFit()) {
				System.out.println("SOLUTION FOUND");
				fin = true;
			}

			evaluation.evaluate(offspring2);
			if (offspring2.getHits() == evaluation.getNumFit()) {
				System.out.println("SOLUTION FOUND");
				fin = true;
			} // CHECK FOR SOLUTION

			// System.out.println("\nOFFSPRING");
			// System.out.println(outputMember(offspring1, EVAL));
			// System.out.println(outputMember(offspring2, EVAL));
			// System.out.println("=====================================");
			break;

		case MUTATION:
			// select();
			// System.out.println("=====================================");
			// System.out.println("MUTATION");
			// System.out.println("SELECTED PARENT");
			Node inRoot = selection.getSelected();
			int index1 = population.getPopulation().indexOf(inRoot);
			Node root3 = tempPopulation.getPopulation().get(index1);
			// System.out.println(outputMember(root3,EVAL));
			offspring1 = genOp.mutate(root3);

			// System.out.println("=====================================");

			
			evaluation.evaluate(offspring1);
			if (offspring1.getHits() == evaluation.getNumFit()) {
				System.out.println("SOLUTION FOUND");
				fin = true;
			}
			// System.out.println("Hits:
			// "+offspring1.getHits()+"!!!!!!!!!!!!!!!");
			// System.out.println("Raw Fitness:
			// "+offspring1.getRawFitness()+"!!!!!!!!!!!!!!!");
			// System.out.println("=====================================");

			newPopulation.getPopulation().add(offspring1);

			// System.out.println("Mutation Point: "+genOp.getPoint1());
			// Node gen = genOp.getGen();
			// System.out.println("Generated Member: "+outputMember(gen,RAW));

			// evaluate();

			// System.out.println("\nOFFSPRING");
			// System.out.println(outputMember(offspring1, RAW));
			// System.out.println("=====================================");
			break;
		}
	}

	public static void main(String[] args) throws FileNotFoundException, CloneNotSupportedException {
		genPop();

System.out.println("=====================================");
 System.out.println("GENERATION 0");
 for (String member : outputPop(GEN,population))
 System.out.println(member);
 System.out.println("=====================================");
	evaluate(population);
	
//	System.out.println("=====================================");
//	 System.out.println("GENERATION 0");
//	 for (String member : outputPop(EVAL,population))
//	 System.out.println(member);
//	 System.out.println("=====================================");
	 
	String member;
//	member = outputMember(population.getFittest(), EVAL);
//	System.out.println("Current Fittest: " + member);
	// long start1 = 0;
int num = 0;
		for (int j = 1; !fin && j <= numGen; j++) {// repeat for number
													// generations or until
													// solution is found
			System.out.println("GENERATION " + j);
			newPopulation = new Population();
		
			newPopulation.setPopulation(new ArrayList<Node>());
start = System.currentTimeMillis();

for (int i = 0; !fin && i < Math.floor(population.getPopSize() * genOp.getCrossRate() / 2); i++) {
	if (newPopulation.getPopulation().size() >= population.getPopSize()){
		num = j;
		break;
	}
				genOp(CROSSOVER);// includes select and reevaluate
			}
//start1 = System.currentTimeMillis();
			for (int i = 0; !fin && i < Math.floor(population.getPopSize() * genOp.getRepRate()); i++) {
				if (newPopulation.getPopulation().size() >= population.getPopSize()){
					num = j;
					break;
				}
				genOp(REPRODUCTION);// includes select and reevaluate
			}		
			//long end1 = System.currentTimeMillis();
			// System.out.println(((end1-start1)/1000.0)+"s REP");
			for (int i = 0; !fin && i < Math.floor(population.getPopSize() * genOp.getMutRate()); i++) {
				if (newPopulation.getPopulation().size() >= population.getPopSize()){
					num = j;
					break;
				}
				genOp(MUTATION);// includes select and reevaluate
			}
	
			while (newPopulation.getPopulation().size() < population.getPopSize())
				genOp(MUTATION);
			
// end = System.currentTimeMillis();
//System.out.println(((end-start)/1000.0)+"s GENOP");


//start = System.currentTimeMillis();

			evaluate(newPopulation);

		//	 end = System.currentTimeMillis();
			//System.out.println(((end-start)/1000.0)+"s EVAL");
			
//			 System.out.println("=====================================");
//			 for (String mem : outputPop(EVAL,newPopulation))
//			 System.out.println(mem);
//			 System.out.println("=====================================");
			 
			population.setPopulation(newPopulation.getPopulation());
			//System.out.println(population.getPopSize()+" :SIZE!!!!!!");
			member = outputMember(population.getFittest(), EVAL);
			System.out.println("Current Fittest: " + member);
			el = true;
			num = j;
		}

		
		 System.out.println("=====================================");
		 for (String mem : outputPop(EVAL,population))
		 System.out.println(mem);
		 System.out.println("=====================================");

		 member = outputMember(population.getFittest(), EVAL);
		System.out.println("\nFINAL SOLUTION: " + member);
	System.out.println("Generation: "+num);
//		member = outputMember(population.getFittest(), RAW);
//		String mod = member.replaceAll("\\s+", "");
//		System.out.println("INFIX NOTATION: " + Infix.toInfix(mod));

//		System.out.println("Seed: " + seed);

		key.close();

	}
}