package Lenses.classification;
import java.util.ArrayList;

public class SetDef {

	private static ArrayList<String> funcSet = new ArrayList<String>();
	private static ArrayList<Integer> aritySet = new ArrayList<Integer>();
	private static ArrayList<Integer> termSet = new ArrayList<Integer>();
	
	public static void init() {// initialise primitives
		termSet.add(1);
			termSet.add(2);
			termSet.add(3);
		funcSet.add("Age");
		aritySet.add(3);
		funcSet.add("SpecPrescription");
		aritySet.add(2);
		funcSet.add("Asigmatic");
		aritySet.add(2);
		funcSet.add("TPR");
		aritySet.add(2);
	}
	
	
	public static int getAttribute(String node){
		if(node=="Age")
			return 0;
		else if(node=="SpecPrescription")
			return 1;
			else if(node=="Asigmatic")
				return 2;
				else if(node=="TPR")
					return 3;
					else
					return -1;
	}
	public static int getChild(int edge){
		if(edge==1)
			return 0;
		if(edge==2)
			return 1;
		if(edge==3)
			return 2;	
		return -1;//error
	}
	
	public static ArrayList<String> getFuncSet() {
		return funcSet;
	}
	public void setFuncSet(ArrayList<String> funcSet) {
		SetDef.funcSet = funcSet;
	}
	public static ArrayList<Integer> getAritySet() {
		return aritySet;
	}
	public void setAritySet(ArrayList<Integer> aritySet) {
		SetDef.aritySet = aritySet;
	}
	public static ArrayList<Integer> getTermSet() {
		return termSet;
	}
	public void setTermSet(ArrayList<Integer> termSet) {
		SetDef.termSet = termSet;
	}
}
