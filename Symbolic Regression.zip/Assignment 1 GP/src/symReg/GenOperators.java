package symReg;

import java.util.*;

public class GenOperators {
	int count = 0;
	Node correct;
	Node parent;

	private int MaxOffspringSize;
	private int point1, point2;
	private Node gen;// generated subtree for mutation

	public int getMaxOffspringSize() {
		return MaxOffspringSize;
	}

	public void setMaxOffspringSize(int maxOffspringSize) {
		MaxOffspringSize = maxOffspringSize;
	}

	public int getPoint1() {
		return point1;
	}

	public void setPoint1(int point1) {
		this.point1 = point1;
	}

	public int getPoint2() {
		return point2;
	}

	public void setPoint2(int point2) {
		this.point2 = point2;
	}

	public Node getGen() {
		return gen;
	}

	public void setGen(Node gen) {
		this.gen = gen;
	}

	public Node reproduce(Node root1) {
//		int index = Main.population.getPopulation().indexOf(root1);
//		Main.population.getPopulation().set(index, root1);// copy chosen
//															// individual into
//															// next generation
return root1;
	}

	public Node mutate(Node root1) throws CloneNotSupportedException {
		
		do {
			point1 = Main.ran.nextInt(getNumNodes(root1)) + 1;

			Node swap1 = traverse(root1, point1);// traverse to index
			Node parent = parent(root1, swap1);// find parent

		
			Population grow = new Population(1, Main.population.getMaxDepth());// 1
																				// member
			grow.setTrivial(true);
			grow.genPop(Population.GROW);
			gen = grow.getPopulation().get(0);// get generated subtree

			
			int index1 = 0;

			//ArrayList<Node> pop = Main.population.getPopulation();
			if (parent == null) {// root
//				int index2 = pop.indexOf(root1);
//				gen.setId(root1.getId());
//				pop.set(index2, gen);
		return gen;
			} else {
				ArrayList<Node> children1 = parent.getChildren();
				for (Node child1 : children1) {
					if (child1.equals(swap1)){
						index1 = children1.indexOf(child1);// 1st or 2nd child
				break;
					}
				}
				children1.set(index1, gen);
				// Main.population.getPopulation().set(index, temp);
			}
		} while (depth(root1) > MaxOffspringSize);// ensure
																						// max
		return root1;																		// depth
																						// is
																						// never
																						// increased
	}

	public Node[] crossover(Node root1, Node root2) throws CloneNotSupportedException {
		//Node root1 = (Node) inRoot1.clone();
		//Node root2 = (Node) inRoot2.clone();
			
		//if(root1==root2)
			//root2 = new Node(root2);
Node[] offspring = new Node[2];
		point1 = Main.ran.nextInt(getNumNodes(root1))+1;
		 point2 = Main.ran.nextInt(getNumNodes(root2))+1;




		Node swap1 = traverse(root1, point1);// traverse to swapping point
			Node swap2 = traverse(root2, point2);

		Node parent1 = parent(root1, swap1);
		Node parent2 = parent(root2, swap2);

		int index1 = 0, index2 = 0;
		//ArrayList<Node> pop = Main.population.getPopulation();

		//Node temp = null;
		if (parent1 == null && parent2 == null) {// both roots

			int id = root1.getId();
			root1.setId(root2.getId());
			root2.setId(id);
//			pop.set(pop.indexOf(root1), root2);
//			pop.set(pop.indexOf(root2), root1);
			offspring[0] = root2;
			offspring[1] = root1;
		}

		else if (parent1 == null) {//root
			swap2.setId(root1.getId());
//			pop.set(pop.indexOf(root1), swap2);
offspring[0] = swap2;
			ArrayList<Node> children2 = parent2.getChildren();
			for (Node child2 : children2) {
				if (child2.equals(swap2)){
					index2 = children2.indexOf(child2);
			break;
				}
			}
			if(root1==root2){
			Node temp = new Node(swap1);
				clone(temp);//changes parent 2 children
				children2.set(index2, temp);
			}
			else
			children2.set(index2, swap1);//SWAP1 is the problem
			//ERROR
			offspring[1] = root2;
		}

		else if (parent2 == null) {
			ArrayList<Node> children1 = parent1.getChildren();
			for (Node child1 : children1) {
				if (child1.equals(swap1)){
					index1 = children1.indexOf(child1);// 1st or 2nd child
			break;
				}
				}
			if(root1==root2){
				Node temp = new Node(swap2);
					clone(temp);//changes parent 2 children
					children1.set(index1, temp);
				}
				else
				children1.set(index1, swap2);//SWAP1 is the problem
			
			offspring[0] = root1;
			
			swap1.setId(root2.getId());
			//pop.set(pop.indexOf(root2), swap1);
			offspring[1] = swap1;
		}

		else {
			ArrayList<Node> children1 = parent1.getChildren();
			for (Node child1 : children1) {// find correct child reference to
											// change
				if (child1.equals(swap1)){
					index1 = children1.indexOf(child1);// 1st or 2nd child
			break;
				}
			}
			children1.set(index1, swap2);
			offspring[0] = root1;
			
			ArrayList<Node> children2 = parent2.getChildren();
			for (Node child2 : children2) {
				if (child2.equals(swap2)){
					index2 = children2.indexOf(child2);
		break;
			}
		}

			children2.set(index2, swap1);
		offspring[1]=root2;
		}
		return offspring;
	}

	// METHODS USED IN MUTATE, CROSSOVER AND REPRODUCTION
	public int getNumNodes(Node node) {
		count = 0;
		return getNumNodesHelper(node);
	}

	public int getNumNodesHelper(Node node) {// since recursion
		if (node != null) {
			count++;
			for (Node n : node.getChildren())
				getNumNodesHelper(n);
		}
		return count;
	}

	private Node parent(Node currentRoot, Node p) {// 2 param is bad
		if (Main.tempPopulation.getPopulation().contains(p)) {// it is a root
			return null;
		} else {
			for (Node n : currentRoot.getChildren()) {
				if (n == p) {// is parent
					parent = currentRoot;
					return parent;
				}
			}
			for (Node nd : currentRoot.getChildren()) {
				parent(nd, p);
			}
		}
		return parent;
	}

	public Node traverse(Node node, int index) {
		count = 0;
		return traverseHelper(node, index);
	}

	public Node traverseHelper(Node node, int index) {
		count++;
		if (node != null) {
			if (count == index) {
				correct = node;
				return correct;
			}
			for (Node n : node.getChildren()) {
				traverseHelper(n, index);
			}
		}
		return correct;
	}

	public static int depth(Node root) {
		if (root == null) {
			System.out.println("Tree is empty");
			return -1;
		}
		Queue<Node> queue = new LinkedList<Node>();
		queue.offer(root);
		// level delimiter
		queue.offer(null);
		int height = 0;
		while (!queue.isEmpty()) {
			Node node = queue.poll();
			if (node == null) {
				if (!queue.isEmpty()) {
					// level delimiter
					queue.offer(null);
				}
				height++;
			} else {
				for (Node n : node.getChildren())
					queue.offer(n);
			}
		}
		return height;
	}
	


	// public static int truncate(Node root,int max) {
	// if (root == null) {
	// System.out.println("Tree is empty");
	// return -1;
	// }
	// Queue<Node> queue = new LinkedList<Node>();
	// queue.offer(root);
	// // level delimiter
	// queue.offer(null);
	// int depth = 1;
	// while (!queue.isEmpty()) {
	// Node node = queue.poll();
	// if(node!=null)
	// System.out.println(node.getValue()+" , "+depth);
	// if(depth==max-1){
	// System.out.println("OUT OF RANGE");
	// if(node!=null)
	// node.getChildren().clear();
	// }
	// if (node == null) {
	// if (!queue.isEmpty()) {
	// // level delimiter
	// queue.offer(null);
	// }
	// if(depth==max){
	// System.out.println("OUT OF RANGE");
	// node.setChildren(null);
	// }
	// depth++;
	// if()
	// } else if(depth<max-1){
	// for (Node n : node.getChildren())
	// queue.offer(n);
	// }
	// }
	// return depth;
	// }

	// public int depth(Node root){
	// int depth=1;
	// boolean first = true;
	// Queue <Node> queue = new LinkedList <Node> ();
	// Node node =root;
	// if(node!=null)
	// {
	// queue.offer(node);
	// while(!queue.isEmpty())
	// {
	// first = true;
	// node = queue.remove();
	// str+=" "+(node.getValue());
	// for (Node n : node.getChildren()){
	// queue.offer(n);
	// if(first){
	// depth++;
	// first = false;
	// }
	// }
	//
	// }
	// }
	// return depth;
	// }

	public void clone(Node node) {//evaluate expression tree
		if(node==null)
			return;
		else if (node.getChildren().size() == 0)// leaf
			return;// x sub 1
		else {
			Node right = new Node(node.getChildren().get(0));
			Node left = new Node(node.getChildren().get(1));
			ArrayList<Node> children = new ArrayList<Node>();
			children.add(right);
			children.add(left);
			//node.getChildren().set(0, new Node(right));
			//node.getChildren().set(1, new Node(left));
			node.setChildren(children);
			clone(node.getChildren().get(0));
			clone(node.getChildren().get(1));
	}	
}
	
}
