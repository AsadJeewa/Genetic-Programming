package symReg;

//import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
//import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Evaluate {

	static double input;
	private int numFitnessCases = 0;
	static double target;
	static int hits;
	static double rawFitness = 0;
	
	private double bound = 0.001;
	private String filename = "";

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public double getBound() {
		return bound;
	}

	public void setBound(double bound) {
		this.bound = bound;
	}

	/** function to evaluate tree */
	public double calculate(Node n) {//evaluate expression tree
		if (n.getChildren().size() == 0)// leaf
			if(n.getValue()=='x')
			return input;
			else return Character.getNumericValue(n.getValue());
			//else return 1;
			else {
			double result = 0.0;
			double left = calculate(n.getChildren().get(0));
			double right = calculate(n.getChildren().get(1));
			char operator = n.getValue();

			switch (operator) {
			case '+':
				result = left + right;
				break;
			case '-':
				result = left - right;
				break;
			case '*':
				result = left * right;
				break;
			case '/':
				if (right == 0.0)
					result = 1;
				else
					result = left / right;
				break;
			default:
				result = left + right;
				break;
			}
			return result;
		}
	}
	
	public int getNumFit() throws FileNotFoundException {
	    // finds resource relative to the class location
	    InputStream url = this.getClass().getResourceAsStream("/res/"+filename);//src is root of classpath

	    numFitnessCases = 0;
	    Scanner sc = new Scanner(url);
		while (sc.hasNextLine()) {
 String line  = sc.nextLine();
		numFitnessCases++;
		}
		sc.close();
				return numFitnessCases;
		}
	
	public void evaluate(Population population) throws FileNotFoundException {
		    // finds resource relative to the class location
		    InputStream url = this.getClass().getResourceAsStream("/res/"+filename);//src is root of classpath

		//File file = new File("res/FitnessCases1.txt");
		    
		// Main.genPop();
		ArrayList<Node> pop = population.getPopulation();
		Scanner sc = new Scanner(url);
		for (Node n : pop) {
			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				String[] str = line.split(" ");
				input = Double.parseDouble(str[0]);
				target = Double.parseDouble(str[1]);
				double res = calculate(n);
				if (Math.abs(res - target) < bound)//hits ratio
					hits++;
				rawFitness += Math.abs(res - target);//calculate raw fitness
			}
			n.setHits(hits);
			n.setRawFitness(rawFitness);
			hits = 0;
			rawFitness = 0.0;
			//sc = new Scanner(file);
			url = this.getClass().getResourceAsStream("/res/"+filename);
			sc = new Scanner(url);
		}
		sc.close();
	}
	
	public void evaluate(Node n) throws FileNotFoundException {
	    InputStream url = this.getClass().getResourceAsStream("/res/"+filename);//src is root of classpath
	Scanner sc = new Scanner(url);

		while (sc.hasNextLine()) {
			String line = sc.nextLine();
			String[] str = line.split(" ");
			input = Double.parseDouble(str[0]);
			target = Double.parseDouble(str[1]);
			double res = calculate(n);
			if (Math.abs(res - target) < bound)//hits ratio
				hits++;
			rawFitness += Math.abs(res - target);//calculate raw fitness
		}
		n.setHits(hits);
		n.setRawFitness(rawFitness);
		hits = 0;
		rawFitness = 0.0;
		//sc = new Scanner(file);
		url = this.getClass().getResourceAsStream("/res/"+filename);
		sc = new Scanner(url);
	sc.close();
}
	
}
