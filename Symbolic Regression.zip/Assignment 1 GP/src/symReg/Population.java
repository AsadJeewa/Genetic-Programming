package symReg;

import java.util.ArrayList;

public class Population implements Cloneable {

	private int popSize = 10;
	private int maxDepth = 6;
	private ArrayList<Node> population;// store root of each member
private boolean trivial = false;
private boolean constant = false;
private boolean ephConstant = false;

	public boolean isEphConstant() {
	return ephConstant;
}

public void setEphConstant(boolean ephConstant) {
	this.ephConstant = ephConstant;
}

	public boolean isConstant() {
	return constant;
}

public void setConstant(boolean constant) {
	this.constant = constant;
}

	public Population(int popSize, int maxDepth) {
		this.popSize = popSize;
		this.maxDepth = maxDepth;
		population = new ArrayList<Node>();
	}
	
	public Population(int popSize, int maxDepth, ArrayList<Node> population, boolean trivial) {
		this.popSize = popSize;
		this.maxDepth = maxDepth;
		this.population = population;
		this.trivial = trivial;
	}

	public Population() {
		population = new ArrayList<Node>();
	}

	public int getPopSize() {
		return popSize;
	}

	public void setPopSize(int popSize) {
		this.popSize = popSize;
	}

	public int getMaxDepth() {
		return maxDepth;
	}

	public void setMaxDepth(int maxDepth) {
		this.maxDepth = maxDepth;
	}

	public ArrayList<Node> getPopulation() {
		return population;
	}

	public void setPopulation(ArrayList<Node> population) {
		this.population = population;
	}

	public boolean isTrivial() {
	return trivial;
}

public void setTrivial(boolean trivial) {
	this.trivial = trivial;
}

	public static final int GROW = 0, FULL = 1, RAMPED = 2;

	static int arity = 2;
	static int count = 0;	
	
private ArrayList<Character> funcSet = new ArrayList<Character>();
	private ArrayList<Character> termSet = new ArrayList<Character>();

	static int curDepth = 0;
	static char ch = ' ';
	static Node curNode, root;
	static String output = "";

	public void init() {// initialise primitives
		termSet.add('x');
		if(constant)
			termSet.add('1');
		if(ephConstant)
	 termSet.add('U');
		
		funcSet.add('+');
		funcSet.add('-');
		funcSet.add('*');
		funcSet.add('/');
	}
	
	public void genPop(int method) {
		init();
		count = 0;
		if (method == GROW || method == FULL) {
			for (int i = 0; i < popSize; i++) {
				genMemberHelper(method, maxDepth);
			}
		}

		else {// RAMPED
//			int depth = 2;
			int num = 0;
			double dblDepth = (double) popSize / (double) (maxDepth - 1);

			boolean whole = dblDepth == Math.ceil(dblDepth);// test no fractions

			int randDepth = Main.ran.nextInt(maxDepth - 1) + 2;
			int numDepth = (int) dblDepth;// floor

			int remainder = popSize - (numDepth * (maxDepth - 1));
			boolean odd = numDepth % 2 != 0;

			for (int i = 2; i <= maxDepth; i++) {// each depth
//				System.out.println("Depth " + depth++);
				for (int j = 0; j < numDepth; j++) {// each member
									if (odd) {
						if (j < (numDepth - 1) / 2)
							genMemberHelper(GROW, i);// grow at current depth
						else if (j < numDepth - 1)
							genMemberHelper(FULL, i);// full at current depth
					} else {
						if (j < numDepth / 2)
							genMemberHelper(GROW, i);// grow at current depth
						else
							genMemberHelper(FULL, i);// full at current depth
					}
				}
		
		
			if (odd) {// remaining 1 choose random fill or grow
			 num = Main.ran.nextInt(2);
			 if (num == 0)
			 genMemberHelper(GROW, randDepth);// grow at current depth
			 else if (num == 1)
			 genMemberHelper(FULL, randDepth);// full at current depth
			 }
			} // for i
			
			 if (!whole) {
			 for (int j = 0; j < remainder; j++) {
			 num = Main.ran.nextInt(2);
			 randDepth = Main.ran.nextInt(maxDepth - 1) + 2;
			 if (num == 0)
			 genMemberHelper(GROW, randDepth);// grow at current depth
			 else if (num == 1)
			 genMemberHelper(FULL, randDepth);
			 }
			 }
		}
	}
	
	
	public void genMemberHelper(int method, int maxDepth) {
		if (!trivial) {// NO TRIVIAL TREES
			genMember(method, maxDepth);
		} else {// allow trivial
			count++;
			int triv = Main.ran.nextInt(2);
			if (triv == 0) {// ALLOW TRIVIAL TREES
				char chRoot = termSet.get(Main.ran.nextInt(termSet.size()));// random
				root = new Node(chRoot, arity);
				root.setId(count);
				population.add(root);
			} else if (triv == 1) {// NO TRIVIAL TREES
				genMember(method, maxDepth);
			}
		}
	}
	
	public void genMember(int method, int maxDepth) {
		count++;
		curDepth = 0;
		char chRoot = funcSet.get(Main.ran.nextInt(funcSet.size()));// random
																// operator
			curDepth++;
		root = new Node(chRoot, arity);
		root.setId(count);
		population.add(root);
		curDepth++;
		curNode = root;
		if (method == GROW)
			createChildrenGrow(curNode, maxDepth);
		else if (method == FULL)
			createChildrenFull(curNode, maxDepth);
	}

	public void createChildrenFull(Node node, int maxDepth) {// expand
																// using
																// full
																// method
		Node child;
		if (curDepth <= maxDepth) {
			for (int i = 0; i < arity; i++) {
				if (curDepth != maxDepth) {
					ch = funcSet.get(Main.ran.nextInt(funcSet.size()));
					child = new Node(ch, arity);
					node.getChildren().add(child);
				}
				else {
					ch = termSet.get(Main.ran.nextInt(termSet.size()));
					int con = 0;
					if(ch=='U'){
					con = 	Main.ran.nextInt(3);
					ch =  Character.forDigit(con, 10);
					//System.out.println(ch+"!!!!!");
					}
					child = new Node(ch, arity);
					node.getChildren().add(child);
				}
				curDepth++;
				createChildrenFull(child, maxDepth);
			}
			curDepth--;
		} else
			curDepth--;// backtrack
		return;
	}

	public void createChildrenGrow(Node node, int maxDepth) {
		Node child = null;

		if (curDepth <= maxDepth) {
			for (int i = 0; i < arity; i++) {
				if (curDepth == maxDepth) {// last level must be terminal
					ch = termSet.get(Main.ran.nextInt(termSet.size()));
					int con = 0;
					if(ch=='U'){
					con = 	Main.ran.nextInt(3);
					ch =  Character.forDigit(con, 10);
					//System.out.println(ch+"!!!!!");
					}
					child = new Node(ch, arity);
					node.getChildren().add(child);
				} else {
					int choice = Main.ran.nextInt(2);// randomly choose terminal or
												// function
					switch (choice) {
					case 0:
						ch = funcSet.get(Main.ran.nextInt(funcSet.size()));
						child = new Node(ch, arity);
						node.getChildren().add(child);
						curDepth++;
						createChildrenGrow(child, maxDepth);// only expand
															// function set
															// element
						break;
					case 1://TERMINAL
						ch = termSet.get(Main.ran.nextInt(termSet.size()));
						int con = 0;
						if(ch=='U'){
						con = 	Main.ran.nextInt(3);
						ch =  Character.forDigit(con, 10);
						//System.out.println(ch+"!!!!!");
						}
						child = new Node(ch, arity);
						node.getChildren().add(child);
						break;
					}
				}
			}
			curDepth--;
		} else
			curDepth--;
		return;
	}
	
	public Node getFittest(){
		double min= Double.MAX_VALUE;
		Node best = new Node();
		for(Node member:population){
			double cur = member.getRawFitness();
			if(cur<min){
				min = cur;
			best = member;
			}
		}
		return best;
	}

		public void clone(Node node) {//evaluate expression tree
			if(node==null)
				return;
			else if (node.getChildren().size() == 0)// leaf
				return;// x sub 1
			else {
				Node right = new Node(node.getChildren().get(0));
				Node left = new Node(node.getChildren().get(1));
				ArrayList<Node> children = new ArrayList<Node>();
				children.add(right);
				children.add(left);
				//node.getChildren().set(0, new Node(right));
				//node.getChildren().set(1, new Node(left));
				node.setChildren(children);
				clone(node.getChildren().get(0));
				clone(node.getChildren().get(1));
		}	
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		ArrayList<Node> tempNodes = new ArrayList<Node>();
		for( Node n:population){
			Node tmp = new Node(n);
			clone(tmp);
			tempNodes.add(tmp);
			}
		return new Population(popSize, maxDepth, tempNodes, trivial);
	}
}
