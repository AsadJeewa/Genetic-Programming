All Parameters are stored in the textfile /res/Param.txt (src/res or bin/res in eclipse)
Fitness Cases are stored in texfiles, in the same location
