package towersofhanoi;

import java.util.ArrayList;
import java.util.Stack;

public class Evaluate {
	
	private int rings = 3;
	public Evaluate(){
	}
	public Evaluate(int rings){
	this.rings = rings;
	}
	
    public int evaluate(Node n) {
        //initialise disks with Ring objects
       Stack<Ring> disk1 = new Stack<Ring>();
       Stack<Ring> disk2 = new Stack<Ring>(); 
       Stack<Ring> disk3 = new Stack<Ring>(); 
       
       for(int i = rings; i > 0; i--)//initial state
           disk1.push(new Ring(i,1));
       
       ArrayList<Stack<Ring>> disks = new ArrayList<Stack<Ring>>();
       disks.add(disk1);
       disks.add(disk2);
       disks.add(disk3);
       
       //end of initialization
       
       execute(n, disks);
       //calculate fitness
       int fitness = 0;
       for(Ring r: disks.get(0)){//first pole
           fitness += r.size;
       }
       for(Ring r: disks.get(1)){//second pole
           fitness += r.size;
       }
       int count = 0;
       for(Ring r: disks.get(2)){//third pole distance to correct position for each block
    	   int curPos = count;    	   
    	   count++;
    	   int correctPos = rings-r.size;
           fitness += Math.abs(correctPos-curPos);
       }
       
       if(fitness < Main.bestFitness){
           Main.bestFitness = fitness;
           Main.bestTree = n;
       }
       
       n.setFitness(fitness);
       n.setHits(fitness);
       return fitness;
           
   }

	public Node getFittest(){//Max or Min
		double max= Main.population.get(0).getRawFitness();//first individual
		Node best = Main.population.get(0);
		for(Node member:Main.population){
			double cur = member.getRawFitness();
			if(cur>max){
				max = cur;
			best = member;
			}
		}
		return best;
	}
	
   public int execute(Node n, ArrayList<Stack<Ring>> disks){
      
       char symbol = n.symbol;
       if(symbol == 'M'){
           int from = execute(n.children[0], disks);
           int to = execute(n.children[1], disks);
           //Move ring from diskFrom to DiskTo
           if(disks.get(from).size() > 0){//ring exists
               int fromSize = disks.get(from).peek().size;//size of ring
               boolean toEmpty = true;
               if(disks.get(to).size() > 0)//empty pole
                   toEmpty = false;
               if(toEmpty || ( fromSize < disks.get(to).peek().size) )//only allow small above big
                   disks.get(to).push(disks.get(from).pop());
           }
           return from;
       }
       else//terminal
           return getIndex(symbol);
   }
   
   private int getIndex(char c){
       switch(c){
           case '1':return 0;
           case '2':return 1;
           case '3':return 2;
       }
       return -1;
   }
}
