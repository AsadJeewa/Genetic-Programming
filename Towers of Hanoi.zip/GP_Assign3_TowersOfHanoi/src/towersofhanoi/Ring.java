package towersofhanoi;

public class Ring {
    int size;//size of ring, 1 (small) to 7 (largest)
    int disk;//disk the ring is currently on
    
    public Ring(int size, int disk){
    	this.size = size;
    	this.disk = disk;
    }
    
    public void moveTo(int disk){
        this.disk = disk;
    }
}
