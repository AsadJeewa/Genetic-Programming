package towersofhanoi;

import java.util.LinkedList;

public class GenOperators {

    private Population logic;
    private int maxDepth;

    public GenOperators(Population logic, int max) {
        this.logic = logic;
        maxDepth = max-1;
    }

    public Node reproduce(Node n) {
        return n;
    }

    public Node mutate(Node n, int depth) {
        Node root = new Node(n);
        //Deep copy 
        LinkedList<Node> tempPop = new LinkedList<>();
        tempPop.add(root);
        boolean isRoot = true;
        while(!tempPop.isEmpty()){
            Node cur = tempPop.removeFirst();
            if(cur.arity>0){
                for(int i = 0; i < cur.arity; i++){
                    cur.children[i] = new Node(cur.children[i]);
                    cur.children[i].parent = cur;
                    tempPop.add(cur.children[i]);
                }
            }
        }

       int count = numNodes(n);
        int rand = logic.rand.nextInt(count);
        count = 0;
        LinkedList<Node> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Node cur = queue.removeFirst();
            if (count == rand) {
                isRoot = count == 0;
                int index = count > 0 ? ((cur == cur.parent.children[0]) ? 0 : 1) : 0;
                Node parent = null;
               // System.out.println("\nMutation Point: " + mutCount + "\tSymbol: " + n1.symbol);
                if(!isRoot)
                    parent = cur.parent;
                
                cur = logic.rand.nextBoolean() ? logic.genMemberFull(depth) : logic.genMemberGrow(depth);//gen new subtree
               // System.out.print("New subtree: ");
                if(!isRoot){
                    parent.children[index] = cur;
                    cur.parent = parent;
                }
                else
                    root = cur;
               // preOrder(n1, true);
                if(count > 0)
                    cur.parent.children[index] = cur;
                //System.out.print("\nOffspring: ");
                root = trimtoDepth(root);
                //preOrder(root, true);
                return root;
            }
                count++;
            
            if (cur.arity > 0) {
                for(int i = 0; i < cur.arity; i++)
                    queue.add(cur.children[i]);
            }
        }

        return n;
    }


    public Node[] crossover(Node n1, Node n2) {

        Node[] offspring = new Node[2];
        int max1 = numNodes(n1);
        int max2 = numNodes(n2);
        int ran1 = logic.rand.nextInt(max1-1)+1;
        int ran2 = logic.rand.nextInt(max2-1)+1;

        int cross1 = 0;
        int cross2 = 0;

        offspring[0] = new Node(n1);
        offspring[1] = new Node(n2);
        //Deep copy 
        LinkedList<Node> tempPop = new LinkedList<>();
        tempPop.add(offspring[0]);
        while(!tempPop.isEmpty()){
            Node temp = tempPop.removeFirst();
            if(temp.arity>0){
                for(int i = 0; i < temp.arity; i++){
                    temp.children[i] = new Node(temp.children[i]);
                    temp.children[i].parent = temp;
                    tempPop.add(temp.children[i]);
                }
            }
        }
        tempPop.add(offspring[1]);
        while(!tempPop.isEmpty()){
            Node temp = tempPop.removeFirst();
            if(temp.arity>0){
                for(int i = 0; i < temp.arity; i++){
                    temp.children[i] = new Node(temp.children[i]);
                    temp.children[i].parent = temp;
                    tempPop.add(temp.children[i]);
                }
            }
        }


        Node subtree1 = null;
        Node subtree2 = null;

        LinkedList<Node> queue = new LinkedList<>();
        queue.add(n1);
        while (!queue.isEmpty()) {//iterate through parent 1 till crossover
            Node node = queue.removeFirst();
            if (cross1 == ran1) {
                subtree1 = node;
                break;
            }
            cross1++;
            for(int i = 0; i < node.arity; i++)
                queue.add(node.children[i]);
            
        }

        while (!queue.isEmpty()) {
            queue.removeFirst();
        }

        queue.add(n2);
        while (!queue.isEmpty()) {//iterate through parent 2 till crossover point
            Node node = queue.removeFirst();
            if (cross2 == ran2) {
                subtree2 = node;
                break;
            }
            cross2++;
            for(int i = 0; i < node.arity; i++)
                queue.add(node.children[i]);
        }
        
        while (!queue.isEmpty()) {
            queue.removeFirst();
        }
        
        cross1 = 0;
        queue.add(offspring[0]);
        Node tmp = null;
        while(!queue.isEmpty()){//crossover for offspring 1
            Node node = queue.removeFirst();
            if (cross1 == ran1) {
                tmp = node.parent;
                node.parent.children[node == node.parent.children[0] ? 0 : (node == node.parent.children[1] ? 1 : 2)] = subtree2; 
                break;
            }
            cross1++;
            for(int i = 0; i < node.arity; i++)
                queue.add(node.children[i]);
        }
        
        while (!queue.isEmpty()) {
            queue.removeFirst();
        }
        
        cross2 = 0;
        queue.add(offspring[1]);
        while (!queue.isEmpty()) {//crossover for offspring 2
            Node node = queue.removeFirst();
            if (cross2 == ran2) {
                subtree1.parent = node.parent;
                node.parent.children[node == node.parent.children[0] ? 0 : node == node.parent.children[1] ? 1 : 2] = subtree1;
                break;
            }
            cross2++;
            for(int i = 0; i < node.arity; i++)
                queue.add(node.children[i]);
        }
        
                subtree2.parent = tmp;
        
        offspring[0] = trimtoDepth(offspring[0]);
        offspring[1] = trimtoDepth(offspring[1]);
        return offspring;
    }
    
    private int numNodes(Node n){
    
        LinkedList<Node> q = new LinkedList<>();
        q.add(n);
        int count = 0;
        while(!q.isEmpty()){
            Node n1 = q.removeFirst();
            count++;
            for(int i = 0; i < n1.arity; i++)
                q.add(n1.children[i]);
        }
        return count;
    }
    
    private Node trimtoDepth(Node n){
        LinkedList<Node> q = new LinkedList<>();
        q.add(n);
        while(!q.isEmpty()){
            Node n1 = q.removeFirst();
            if(n1.depth > maxDepth){
                Node parent = n1.parent;
                for(int i = 0; i < parent.arity; i++)
                    parent.children[i] = null;
                int rand = logic.rand.nextInt(2);
                parent.symbol = ( rand == 1 )? '1': (rand == 2 ? '2' : '3');
            }
            for(int i = 0; i < n1.arity; i++)
                q.add(n1.children[i]);
        }
        return n;
    }
}
