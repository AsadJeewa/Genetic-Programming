package towersofhanoi;

import java.util.Random;
import java.util.Stack;
public class Population {
    private char[] functionSet;
    private char[] terminalSet;
    public Random rand;
    
    public Population(char[] func, char[]term, long seed){
        functionSet = func;
        terminalSet = term;
        rand = new Random(seed);
    }
    
    public Node genMemberGrow(int maxDepth){
        Stack<Node> stack = new Stack<Node>();
        Node root = growHelper(1, maxDepth);
        stack.push(root);
        while(stack.size() > 0){
            Node node = stack.pop();
            for(int i = 0; i < node.arity; i++){
                if(node.depth+1 <= maxDepth){
                    node.children[i] = genChildrenGrow(node.depth+1,maxDepth);
                    node.children[i].parent = node;
                    stack.push(node.children[i]);
                }
            }
        }
        return root;
    }
    
    private Node growHelper(int depth, int maxDepth){
        char symbol;
        int funcLen = functionSet.length;
        
        int random = rand.nextInt(funcLen);
        symbol = depth < maxDepth ? functionSet[random] : terminalSet[rand.nextInt(terminalSet.length)];
        Node node = new Node(symbol, 2, depth);
        return node;
    }
    
    private Node genChildrenGrow(int depth, int maxDepth){
        char symbol;
        int funcLen = functionSet.length;
        int termLen = terminalSet.length;
        int max = termLen+ (depth < maxDepth-1 ? funcLen : 0);
        
        int opt = rand.nextInt(max);
        if(opt >= termLen)
            symbol = functionSet[opt-termLen];
        else
            symbol = terminalSet[opt];
        Node node = new Node(symbol, opt >= termLen ?2 : 0, depth);
        return node;
    }
    
    public Node genMemberFull(int maxDepth){
        Stack<Node> stack = new Stack<Node>();
        Node root = genChildrenFull(0, maxDepth);
        stack.push(root);
        while(stack.size() > 0){
            Node node = stack.pop();
            for(int i = 0; i < node.arity; i++){
                if(node.depth+1 < maxDepth){
                    node.children[i] = genChildrenFull(node.depth+1, maxDepth);
                    node.children[i].parent = node;
                    stack.push(node.children[i]);
                }
            }
        }
        return root;
    }
    
    private Node genChildrenFull(int depth, int maxDepth){
        char symbol;
        int funcLen = functionSet.length;
        int termLen = terminalSet.length;
        boolean function = (depth < maxDepth-1);//not leaf
        
        int random = rand.nextInt(function ? funcLen : termLen);
        symbol = function ? functionSet[random] : terminalSet[random];
        Node node = new Node(symbol, function ? 2: 0, depth);
        return node;
    }    
}
