package towersofhanoi;

import java.util.LinkedList;

public class Select {
    
    Population popLogic;
    GenOperators genOp;
    
    public Select(Population pop, GenOperators genOp){
        this.popLogic = pop;
        this.genOp = genOp;
    }
    
    public Node select(LinkedList<Node> population, int tourn_size){
        LinkedList<Node> tournament = new LinkedList<>();
            for (int i = 0; i < tourn_size; i++) {
                tournament.add(population.get(popLogic.rand.nextInt(population.size())));
            }

            Node min = tournament.get(0);
            for (Node n : tournament) {
                if ((double) (n.getRawFitness()) < (double) min.getRawFitness()) {
                    min = n;
                }
            }
            return min;
    }
}
