package towersofhanoi;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
//import java.net.URL;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {

    static char[] functionSet = {'M'};//,'C'};//move a disk from child one to child two
    static char[] terminalSet = {'1', '2', '3'}; // disk holders one two and three
    static BufferedWriter bw;

    
    static LinkedList<Node> population = new LinkedList<Node>();
    Population popLogic;
    GenOperators genOp;
    Select selection;
    Evaluate evaluate;
    static int gen =0;
    final int REPRODUCE = 1;
    final int MUTATE = 2;
    final int CROSSOVER = 3;
    int solutionsFound = 0;
    long seed = 0;
    int rings = 3;
    
    static double bestFitness = Double.MAX_VALUE;
    static Node bestTree = null;
    

    public static void main(String[] args) throws IOException {
//    	URL file = Main.class.getResource("/res/result.txt");
        //FileWriter fw = new FileWriter(file.getPath());
         bw = new BufferedWriter(
        		new FileWriter ("result.txt"));
    	new Main();
    	bw.newLine();
    	bw.write("END");
    	bw.close();
    }

    public Main() throws IOException {
        //size, depth, method
		Scanner key = new Scanner(System.in);
		//System.out.println("Enter the name of the input file (eg. input.txt): ");
		do{
		System.out.println("Enter the number of rings: (3-7)");
		rings = key.nextInt();
		}
		while(rings < 3 || rings > 7);
		InputStream url = Main.class.getResourceAsStream("/res/param.txt");
    	Scanner in = new Scanner(url);

		int size = in.nextInt();
		in.nextLine();
		int depth = in.nextInt();
		in.nextLine();
       int method = in.nextInt();
       in.nextLine();
		int tournSize = in.nextInt();
		in.nextLine();
		int max_offspring_size = in.nextInt();
		in.nextLine();
		if (max_offspring_size <= depth) {
		    max_offspring_size = depth + 1;
		}
//       int mutation_depth = in.nextInt();
//       in.nextLine();
		double repRate = in.nextDouble();
		in.nextLine();
		double mutRate = in.nextDouble();
		in.nextLine();
		double crossRate = in.nextDouble();
		in.nextLine();
		int numGen = in.nextInt();
		in.nextLine();
		seed = in.nextLong();
		if (seed == 0) {
		    seed = System.currentTimeMillis();
		}
		key.close();
		in.close();

		popLogic = new Population(functionSet, terminalSet, seed);
		genOp = new GenOperators(popLogic, max_offspring_size);
		selection = new Select(popLogic, genOp);
evaluate = new Evaluate(rings);
		System.out.println("\n*****Parameters*****");
		System.out.println("Population Size: " + size);
		System.out.println("Max Tree Depth: " + depth);
		System.out.println("Method: " + ((method > 1) ? ((method > 2) ? "Ramped half-and-half" : "Full") : "Grow"));
		System.out.println("Tournament Size: " + tournSize);
		System.out.println("Maximum Offspring Size: " + max_offspring_size);
//		System.out.println("Mutation Depth: " + mutation_depth);
		System.out.println("Reproduction Rate: " + repRate);
		System.out.println("Mutation Rate: " + mutRate);
		System.out.println("Crossover Rate: " + crossRate);
		System.out.println("Maximum Generation: " + numGen);
		
		    while(!population.isEmpty())
		        population.removeFirst();
		    boolean fin = false;
		    System.out.println("Random Seed: " + seed);
	        System.out.println("\nCurrent Fittest:");
		    switch (method) {
		        case 1:
		            for (int i = 0; i < size; i++) {
		                population.add(popLogic.genMemberGrow(depth));
		            }
		            break;
		        case 2:
		            for (int i = 0; i < size; i++) {
		                population.add(popLogic.genMemberFull(depth));
		            }
		            break;
		        case 3://half and half
		            int[] numTrees = new int[depth - 1];
		            for (int i = 0; i < numTrees.length; i++) {
		                numTrees[i] = (int) Math.floor(size / (depth - 1));
		            }

		            if (size % (depth - 1) > 0) {
		                int trees = size % (depth - 1);
		                for (int i = 0; i < trees; i++) {
		                    numTrees[popLogic.rand.nextInt(depth - 2)]++;
		                }
		            }
		            for (int i = 2; i <= depth; i++) {//for each tree depth, generate half full and half grow trees
		                for (int j = 0; j < (int) Math.floor(numTrees[i - 2] / 2); j++) {
		                    population.add(popLogic.genMemberFull(i));
		                    population.add(popLogic.genMemberGrow(i));
		                }
		                if (numTrees[i - 2] % 2 > 0)//random method for odd tree
		                {
		                    population.add(popLogic.rand.nextBoolean() ? popLogic.genMemberFull(i) : popLogic.genMemberGrow(i));
		                }
		            }

		    }
		   

		    //iterate through trees to test
		    for (Node n : population) {
		        if (evaluate.evaluate(n) == 0) {
		            fin = true;
		            solutionsFound++;
		            System.out.println("\nGeneration 0");
		            outputMember(n, true);
		            System.out.println("\nRaw Fitness:"+n.getRawFitness());
		            break;
		        }
		    }
		    if (!fin) {
		        for (int genCount = 0; genCount < numGen; genCount++) {
		            LinkedList<Integer> operators = new LinkedList<>();
		            for (int i = 0; i < repRate * size; i++) {
		                operators.add(REPRODUCE);
		            }
		            for (int i = 0; i < mutRate * size; i++) {
		                operators.add(MUTATE);
		            }
		            for (int i = 0; i < crossRate * size / 2; i++) {
		                operators.add(CROSSOVER);
		            }
		            LinkedList<Node> tempPopulation = new LinkedList<>();
		            int counter = 0;
		            while (counter < size) {
		                int index = popLogic.rand.nextInt(operators.size());
		                int operator = operators.get(index);
		                operators.remove(index);
		                switch (operator) {
		                    case 1://Reproduction
		                        Node rep = genOp.reproduce(selection.select(population, tournSize));
		                        //list.remove(rep);
		                        tempPopulation.add(rep);
		                        counter++;
		                        break;
		                    case 2://Mutation
		                        Node parent = selection.select(population, tournSize);
		                        Node mutated = genOp.mutate(parent, depth);
		                       tempPopulation.add(mutated);
		                        counter++;
		                        break;
		                    case 3://Crossover
		                        if (counter + 2 > size) {
		                            operators.add(repRate > mutRate ? REPRODUCE : MUTATE);
		                            break;
		                        }
		                        Node parent1 = selection.select(population, tournSize);
		                        Node parent2 = selection.select(population, tournSize);
		                        Node[] offspring = genOp.crossover(parent1, parent2);
		                        tempPopulation.add(offspring[0]);
		                        tempPopulation.add(offspring[1]);
		                        counter += 2;
		                        break;
		                }
		            }

		            while (!population.isEmpty()) {
		                population.removeFirst();
		            }
		            while (!tempPopulation.isEmpty()) {
		                Node n = tempPopulation.getFirst();
		                population.add(n);
		                tempPopulation.remove(n);
		            }
//		          Node fit = evaluate.getFittest();
		            gen = genCount;
		          System.out.println("\nGeneration "+(genCount));
//			        outputMember(fit, true);
//			        System.out.println(" |\tRaw Fitness:"+fit.getHits());
			        System.out.print("Fittest Individual: ");
		          outputMember(bestTree, true);
			        System.out.println("\nRaw Fitness:"+bestFitness);
			        
		            for (Node n : population) {
		                //opLog.preOrder(n, true);
		                if (evaluate.evaluate(n) == 0) {//evaluate each node
		                    fin = true;
		                    solutionsFound++;
		                    System.out.println("\nSOLUTION FOUND");
		                    System.out.println("Generation " + (genCount + 1));
		                    outputMember(n, true);//output
					        System.out.println("\nRaw Fitness:"+n.getRawFitness());
		    		        System.out.println();
		                    break;
		                }
		            }
		            if (fin) {//fitness is 6
		                break;
		            }
		        }
		    }
		    if(!fin){
		    System.out.println("BEST SOLUTION");
		     // Node fit = evaluate.getFittest();
            System.out.println("Generation " + (gen + 1));
		        outputMember(bestTree, true);
		        System.out.println("\nRaw Fitness:"+bestFitness);
		    }
		    outputMemberFile(bestTree);
				    System.out.println(seed);
    }
    
 
    static void outputMemberFile(Node s) throws IOException {
        if (s == null) {
            return;
        }
        if (s.arity > 0) {
                bw.write(s.toString() + " ");//function
            
            for(int i = 0; i < s.arity; i++)
                outputMemberFile(s.children[i]);
        } else
        	bw.write(s.toString()+" ");
        
    }
    
    static void outputMember(Node s, boolean print) {
        if (s == null) {
            return;
        }
        if (s.arity > 0) {
            if (print)
                System.out.print(s.toString() + " ");//function
            
            for(int i = 0; i < s.arity; i++)
                outputMember(s.children[i], print);
        } else
            System.out.print(s.toString()+" ");
        
    }
}
