
package towersofhanoi;

public class Node {
    int arity;
    char symbol;
     public Node[] children;
     int depth;
     private double rawFitness = 0.0;
     private int hits = 0;
     Node parent;
    
    public Node(char symbol, int arity, int depth){
        this.symbol = symbol;
        this.arity = arity;
        children = new Node[arity];
        this.depth = depth;
    }
    
    public Node(Node n) {
        this.arity = n.arity;
        this.symbol = n.symbol;
        this.children = new Node[n.arity];
        if(arity > 0)
            for(int i = 0; i < arity; i++)
                children[i] = n.children[i];
        
        this.depth = n.depth;
        this.parent = n.parent;
        this.hits = n.getHits();
        this.rawFitness = n.getRawFitness();
    }
    
    public void setFitness(double rawFit){
        this.rawFitness = rawFit;
    }
    
    public double getRawFitness(){
        return rawFitness;
    }
    
    public void setHits(int hits){
        this.hits = hits;
    }
    
    public int getHits(){
        return hits;
    }
    
    @Override
    public String toString(){
        return this.symbol+"";
    }
}
