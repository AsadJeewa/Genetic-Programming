All Parameters are stored in the textfile /res/Param.txt
